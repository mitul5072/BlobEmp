﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeApp.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        [Required]
        public string FullName { get; set; }
        [Required]
        public string EmployeeCode { get; set; }
        [Required]
        public string Position { get; set; }
        /* [Required]
        public IFormFile FileUpload { get; set; }*/

        [Required]
        public DateTime DateOfBirth { get; set; }
    }
}
